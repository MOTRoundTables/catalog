# catalog tools - ver. 0.2

# files list - # Please specify:
# dr is the directory where the zip was opened
# fl is the name of the meta-file (without file type - assumed .xlsx)

x = array(list(), 20)

# ido files

x[[1]]$dr = "C:/Users/marsz/Desktop/zvl/tmp24/Data/tayarut/v0.4/tourism20162017/"
#x[[1]]$dr = "C:/Users/idshk/Downloads/OneDrive_2023-01-03/version 0.2/"
x[[1]]$fl = "tourists_survey_2016-17_meta"

# amit files
x[[2]]$dr = "C:/Users/marsz/Desktop/zvl/tmp24/Data/amit/busvalid/"
x[[2]]$fl = "Metadata-Bus_Tickets_Validation_Survey_2021"

x[[3]]$dr = "C:/Users/marsz/Desktop/zvl/tmp24/Data/amit/razon/"
x[[3]]$fl = "Metadata-National_Satisfaction_Public_Transport"

x[[4]]$dr = "C:/Users/marsz/Desktop/zvl/tmp24/Data/amit/pubopinion/"
x[[4]]$fl = "Metadata-Public_opinion_on_public_transportation_Survey_2021"
      
x[[5]]$dr = "C:/Users/marsz/Desktop/zvl/tmp24/Data/amit/obstru/"
x[[5]]$fl = "Metadata-Barriers in public transportation survey_2021"

x[[6]]$dr = "C:/Users/marsz/Desktop/zvl/tmp24/Data/amit/info/"
x[[6]]$fl = "Metadata-Information_on_public_transportation_Survey_2021"

# ofer files

x[[7]]$dr = "C:/Users/marsz/Desktop/zvl/tmp24/Data/hzv/accid_taz/"
x[[7]]$ fl = "accid_taz_metadata"


# -------------------------------------------------------




